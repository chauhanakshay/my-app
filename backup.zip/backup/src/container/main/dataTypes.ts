export interface TableData {
  id: number,
  userId: number,
  title: string,
  completed: string | boolean
}