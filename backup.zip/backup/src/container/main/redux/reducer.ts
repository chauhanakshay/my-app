const default_state = {
  itemsCount: 0,
  tableData: []
}
export const rootReducer = function (state = default_state, action: any) {
  switch (action.type) {
    case "SET_DATA":
      return Object.assign({}, state, {
        tableData: action.payload,
        loading: false
      });
    case "GET_DATA":
      return Object.assign({}, state, {
        loading: true
      });
    case "DELETE_RECORDS":
      let tempArray = state.tableData;
      action?.records?.forEach(element => {
        state.tableData?.forEach((obj: { id: number }, ind: number) => {
          element === obj.id && tempArray.splice(ind, 1)
        })
      });
      return Object.assign({}, state,
        {
          tableData: tempArray,
          loading: false
        });
    default:
      return state;
  }
};
