
import { put, takeEvery, fork, all } from 'redux-saga/effects';

function* getData() {
  try {
    const requestUrl = "https://jsonplaceholder.typicode.com/todos";
    const res = yield fetch(requestUrl).then(response => response.json(),);
    yield put({ type: "SET_DATA", payload: res });
  } catch (error) {
    yield put({ type: "SET_DATA", payload: [] });
    yield put({
      type: "SET_LOADING",
      payload: false
    });
  }
}
function* sendUserName(action) {
  try {
    console.log(action);
    const requestUrl = " https://api.github.com/users/"+action?.records ;
    const res = yield fetch(requestUrl).then(response => response.json(),);
    // yield put({ type: "SET_DATA", payload: res });
  } catch (error) {
    /* yield put({ type: "SET_DATA", payload: [] });
    yield put({
      type: "SET_LOADING",
      payload: false
    }); */
  }
}

function* getOrderAsync() {
  yield takeEvery("GET_DATA", getData);
}
function* sendUserNameAsync() {
  yield takeEvery("sendUserName", sendUserName);
}
export default function* () {
  yield all([
    fork(getOrderAsync),
    fork(sendUserNameAsync)
  ]);
}

