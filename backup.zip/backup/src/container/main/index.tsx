import React, { useEffect } from "react";
import { connect } from 'react-redux';
import { DataGrid, GridColDef, GridValueGetterParams } from '@material-ui/data-grid';
import { Button, LinearProgress, TextField } from "@material-ui/core";

import "./main.scss";
import { TableData } from "./dataTypes";

function MainComponentFunction(props) {
  const { tableData } = props;
  const [selectedIndex, setSelectedIndex] = React.useState([]);
  const [userName, setUserName] = React.useState("");
  const [pageSize, setPageSize] = React.useState(25)
  const columns: GridColDef[] = [
    {
      field: 'userId',
      headerName: 'User ID',
      flex: 1,
    },
    {
      field: 'id',
      headerName: 'ID',
      flex: 1,
    },
    {
      field: 'title',
      headerName: 'Title',
      flex: 2,

    },
    {
      field: 'completed',
      headerName: 'Completed',
      flex: 1,
    },
  ];
  let rows: TableData[] = [];
  tableData.forEach((val: TableData) => {
    rows.push({
      id: val.id,
      userId: val.userId,
      title: val.title,
      completed: val.completed
    })
  });
  const handleEdit = () => {
    props.deleteRecords(selectedIndex);
    setSelectedIndex([]);
  }
  const sendUserName = () => {
    props.sendUserName(userName);
  }
  // On load of the card
  useEffect(() => {
    props.getData();
  }, []);

  return (
    (!props.loading ? <div className="MainDiv">
      <TextField type="text" variant="outlined" onChange={(e) => { 
        console.log(userName);
        setUserName(e.target.value)}} />
      
      <Button variant="contained" color="primary" onClick={() => { sendUserName() }} className="DeleteButton">
        send username
      </Button>
      <DataGrid
        rows={rows}
        loading={props.loading}
        columns={columns}
        pageSize={pageSize}
        checkboxSelection
        disableSelectionOnClick
        onSelectionModelChange={(e: number[]) => setSelectedIndex(e)}
        onPageSizeChange={(val: number) => setPageSize(val)}
      />
      <Button variant="contained" color="primary" onClick={() => { handleEdit() }} disabled={selectedIndex?.length === 0} className="DeleteButton">
        Edit
      </Button>
    </div> :
      <div className="LinearProgress" >
        <div className="LoadingText">Loading........</div>
        <LinearProgress />
      </div>)
  )
}
const mapStateToProps = state => {
  return {
    ...state
  };
};
const mapDispatchToProps = dispatch => {
  return {
    getData: () => dispatch({ type: 'GET_DATA' }),
    deleteRecords: (records) => dispatch({ type: 'DELETE_RECORDS', records: records }),
    sendUserName: (data) => dispatch({ type: 'sendUserName', records: data })
  }
};

export const MainComponent = connect(mapStateToProps, mapDispatchToProps)(MainComponentFunction);
