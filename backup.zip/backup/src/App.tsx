
import './App.scss';
import { MainComponent } from './container/main';

function App() {
  return (
    <div className="App">
      <MainComponent />
    </div>
  );
}

export default App;
